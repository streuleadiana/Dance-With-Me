package com.dancewithme.app.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.dancewithme.app.data.DrillResult
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Helper pentru oferirea feedback-ului vocal la finalul antrenamentului folosind
 * motorul nativ Android [TextToSpeech].
 *
 * Generează automat rezumatul vocal al scorului DTW și evidențiază articulația cu cea mai
 * mare abatere unghiulară pentru ca dansatorul să știe exact ce trebuie să corecteze.
 */
class TtsFeedbackHelper(
    context: Context,
    private val preferredLocale: Locale = Locale.forLanguageTag("ro-RO")
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isReady: Boolean = false
    private var pendingSpeechText: String? = null

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status == TextToSpeech.SUCCESS) {
            val langResult = engine.setLanguage(preferredLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Limba $preferredLocale nu este disponibilă pe dispozitiv. Se folosește Locale.US.")
                engine.setLanguage(Locale.US)
            }
            engine.setSpeechRate(1.0f)
            engine.setPitch(1.0f)
            isReady = true

            pendingSpeechText?.let { textToSpeak ->
                pendingSpeechText = null
                speakText(textToSpeak)
            }
        } else {
            Log.e(TAG, "Inițializarea Android TextToSpeech a eșuat cu status=$status")
        }
    }

    /**
     * Construiește și redă vocal feedback-ul complet pentru un [DrillResult].
     */
    fun speakDrillResult(result: DrillResult) {
        val feedbackMessage = buildFeedbackText(result)
        speakText(feedbackMessage)
    }

    /**
     * Redă un text arbitrar prin motorul TTS. Dacă motorul încă se inițializează,
     * păstrează textul în coadă și îl rostește imediat ce `onInit` confirmă disponibilitatea.
     */
    fun speakText(text: String) {
        if (text.isBlank()) return
        val engine = tts
        if (!isReady || engine == null) {
            pendingSpeechText = text
            return
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dance_with_me_feedback")
    }

    /**
     * Oprește redarea curentă și eliberează resursele native ale serviciului [TextToSpeech].
     */
    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (t: Throwable) {
            Log.w(TAG, "Eroare la închiderea TextToSpeech: ${t.message}")
        } finally {
            tts = null
            isReady = false
        }
    }

    companion object {
        private const val TAG = "TtsFeedbackHelper"

        /**
         * Generează textul de feedback în limba română pe baza scorului DTW și a erorilor pe articulații.
         * Această funcție este pură (fără dependențe Android) și poate fi testată unitar.
         */
        fun buildFeedbackText(result: DrillResult): String {
            val roundedTotal = result.totalScore.roundToInt()
            val roundedForm = result.formScore.roundToInt()
            val roundedTiming = result.timingScore.roundToInt()

            val worstJointEntry = result.jointErrors.maxByOrNull { it.value }

            val intro = when {
                roundedTotal >= 85 -> "Excelent! Ai obținut un scor total de $roundedTotal la sută."
                roundedTotal >= 65 -> "Foarte bine! Scorul tău total este $roundedTotal la sută."
                else -> "Antrenament finalizat cu un scor de $roundedTotal la sută."
            }

            val details = "Scorul pentru formă este $roundedForm la sută, iar sincronizarea $roundedTiming la sută."

            val jointAdvice = if (worstJointEntry != null && worstJointEntry.value >= 8.0f) {
                val errDeg = worstJointEntry.value.roundToInt()
                "Atenție la ${worstJointEntry.key}, unde ai avut o abatere medie de $errDeg grade."
            } else {
                "Toate unghiurile articulare au fost foarte precise. Bravo!"
            }

            return "$intro $details $jointAdvice"
        }
    }
}
