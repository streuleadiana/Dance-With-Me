package com.dancewithme.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dancewithme.app.data.DrillResult

/**
 * Ecranul de rezultate (`ResultScreen`).
 * Afișează scorul total, scorul de formă, scorul de sincronizare (Timing) și eroarea medie în grade
 * pentru fiecare articulație, declanșând automat feedback-ul vocal (TTS) la deschidere.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    danceTitle: String,
    result: DrillResult,
    onSpeakResult: (DrillResult) -> Unit,
    onRetryDrill: () -> Unit,
    onBackToMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Declanșăm feedback-ul vocal TTS imediat ce se afișează rezultatul DTW
    LaunchedEffect(result) {
        onSpeakResult(result)
    }

    val scoreColor = when {
        result.totalScore >= 80f -> Color(0xFF2E7D32)
        result.totalScore >= 55f -> Color(0xFFEF6C00)
        else -> Color(0xFFC62828)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Rezultate Antrenament (DTW)") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card Scor Principal
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = danceTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${result.totalScore}%",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = scoreColor
                    )
                    Text(
                        text = "Scor General DTW",
                        style = MaterialTheme.typography.labelLarge
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ScoreMetricColumn(
                            label = "Formă (Unghiuri)",
                            score = result.formScore
                        )
                        ScoreMetricColumn(
                            label = "Timing (Ritm)",
                            score = result.timingScore
                        )
                    }
                }
            }

            // Card Erori pe Articulații
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Abaterea Medie pe Articulații (în grade):",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    result.jointErrors.forEach { (jointName, errorDeg) ->
                        JointErrorRow(jointName = jointName, errorDegrees = errorDeg)
                    }
                }
            }

            // Buton pentru re-ascultarea feedback-ului vocal TTS
            OutlinedButton(
                onClick = { onSpeakResult(result) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Redă din nou Feedback-ul Audio (TTS)")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onBackToMenu,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Meniu Principal")
                }
                Button(
                    onClick = onRetryDrill,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Repetă Dansul")
                }
            }
        }
    }
}

@Composable
private fun ScoreMetricColumn(
    label: String,
    score: Float
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "${score}%",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun JointErrorRow(
    jointName: String,
    errorDegrees: Float
) {
    // 0° este perfect, 45°+ este eroare mare
    val normalizedError = (errorDegrees / 45f).coerceIn(0f, 1f)
    val barColor = when {
        errorDegrees <= 10f -> Color(0xFF2E7D32)
        errorDegrees <= 22f -> Color(0xFFEF6C00)
        else -> Color(0xFFC62828)
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = jointName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "±${errorDegrees}°",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = barColor
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { 1f - normalizedError },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = barColor
        )
    }
}
