package com.dancewithme.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dancewithme.app.ai.PoseExtractionOutput
import com.dancewithme.app.data.AngleVector
import com.dancewithme.app.data.DanceRepository
import com.dancewithme.app.data.DefaultDanceRepository
import com.dancewithme.app.data.DrillResult
import com.dancewithme.app.data.Point3D
import com.dancewithme.app.data.PoseFrame
import com.dancewithme.app.data.ReferenceDance
import com.dancewithme.app.engine.DtwEngine
import com.dancewithme.app.engine.EngineConfig
import com.dancewithme.app.engine.JointAngleCalculator
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel central (MVVM / MVI) care coordonează:
 * - Selecția coregrafiei de referință (`ReferenceDance`).
 * - Starea de calibrare a înclinării telefonului (~90°).
 * - Colectarea în timp real a unui buffer de până la 600 de cadre (`List<AngleVector>`, 20s @ 30 FPS).
 * - Evaluarea în timp real a posturii (pentru colorarea stickman-ului în verde/roșu pe `Canvas`).
 * - Lansarea algoritmului matematic DTW în `viewModelScope` pe `defaultDispatcher` (`Dispatchers.Default`)
 *   la expirarea celor 20 de secunde sau la umplerea bufferului de 600 de cadre, fără a bloca UI-ul.
 */
class DrillViewModel(
    private val repository: DanceRepository = DefaultDanceRepository(),
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.Default
) : ViewModel() {

    private val _uiState = MutableStateFlow(DrillUiState())
    val uiState: StateFlow<DrillUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<DrillEvent>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<DrillEvent> = _events.asSharedFlow()

    /**
     * Bufferul intern thread-safe pentru stocarea secvenței de [AngleVector] a utilizatorului
     * (capacitate maximă: 600 cadre = 20 secunde * 30 FPS).
     */
    private val bufferLock = Any()
    private val angleBuffer = ArrayList<AngleVector>(MAX_BUFFER_FRAMES)

    private var timerJob: Job? = null
    private var evaluationJob: Job? = null

    init {
        loadAvailableDances()
    }

    /**
     * Încarcă lista de dansuri de referință din [DanceRepository].
     */
    fun loadAvailableDances() {
        viewModelScope.launch {
            val dances = repository.getAvailableDances()
            _uiState.update { current ->
                current.copy(
                    availableDances = dances,
                    selectedDance = current.selectedDance ?: dances.firstOrNull()
                )
            }
        }
    }

    /**
     * Selectează dansul curent după ID (ex: din `MainMenuScreen`).
     */
    fun selectDance(danceId: String) {
        val found = _uiState.value.availableDances.find { it.id == danceId }
        if (found != null) {
            _uiState.update {
                it.copy(
                    selectedDance = found,
                    remainingSeconds = found.durationSec,
                    phase = DrillPhase.READY,
                    capturedFramesCount = 0
                )
            }
        } else {
            viewModelScope.launch {
                val dance = repository.getDanceById(danceId)
                if (dance != null) {
                    _uiState.update {
                        it.copy(
                            selectedDance = dance,
                            remainingSeconds = dance.durationSec,
                            phase = DrillPhase.READY,
                            capturedFramesCount = 0
                        )
                    }
                }
            }
        }
    }

    /**
     * Actualizează unghiul de înclinare al telefonului citit de la `GravitySensorManager` (în `CalibrationScreen`).
     * Telefonul este considerat calibrat când este aproape vertical (~90° ± [CALIBRATION_TOLERANCE_DEG]).
     */
    fun updatePhoneTilt(tiltDegrees: Float) {
        val isWithinTarget = kotlin.math.abs(tiltDegrees - TARGET_TILT_DEG) <= CALIBRATION_TOLERANCE_DEG
        _uiState.update {
            it.copy(
                currentPhoneTiltDeg = tiltDegrees,
                isCalibrated = isWithinTarget
            )
        }
    }

    /**
     * Pornește sesiunea de dans (Drill). Poate fi apelat atât manual din UI, cât și prin comanda
     * vocală offline Vosk ("Start").
     *
     * @param withPreCountdown Dacă este `true`, numără invers 3..2..1 secunde înainte de a porni înregistrarea.
     */
    fun startDrill(withPreCountdown: Boolean = false) {
        val currentPhase = _uiState.value.phase
        if (currentPhase == DrillPhase.RECORDING || currentPhase == DrillPhase.EVALUATING) {
            return
        }

        timerJob?.cancel()
        evaluationJob?.cancel()

        synchronized(bufferLock) {
            angleBuffer.clear()
        }

        val durationSec = _uiState.value.selectedDance?.durationSec ?: EngineConfig.DRILL_DURATION_SECONDS

        if (withPreCountdown) {
            _uiState.update {
                it.copy(
                    phase = DrillPhase.COUNTDOWN_TO_START,
                    preDrillCountdownSec = PRE_COUNTDOWN_SECONDS,
                    remainingSeconds = durationSec,
                    capturedFramesCount = 0,
                    errorMessage = null
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    phase = DrillPhase.RECORDING,
                    preDrillCountdownSec = 0,
                    remainingSeconds = durationSec,
                    capturedFramesCount = 0,
                    errorMessage = null
                )
            }
        }

        timerJob = viewModelScope.launch {
            if (withPreCountdown) {
                for (cnt in PRE_COUNTDOWN_SECONDS downTo 1) {
                    _uiState.update { it.copy(preDrillCountdownSec = cnt) }
                    delay(1_000L)
                }
                _uiState.update {
                    it.copy(
                        phase = DrillPhase.RECORDING,
                        preDrillCountdownSec = 0,
                        remainingSeconds = durationSec,
                        capturedFramesCount = 0
                    )
                }
            }

            for (remaining in durationSec downTo 1) {
                _uiState.update { it.copy(remainingSeconds = remaining) }
                delay(1_000L)
                // Dacă bufferul de 600 de cadre s-a umplut deja și a declanșat DTW-ul, ieșim din timer
                if (_uiState.value.phase != DrillPhase.RECORDING) {
                    return@launch
                }
            }

            _uiState.update { it.copy(remainingSeconds = 0) }
            finishAndEvaluateDrill()
        }
    }

    /**
     * Primește output-ul complet de la [com.dancewithme.app.ai.PoseLandmarkerHelper] / [com.dancewithme.app.camera.PoseAnalyzer]
     * (atât cadrul 3D cât și reperele 2D normalizate pentru desenarea stickman-ului în `Canvas`).
     */
    fun onPoseExtractionOutput(output: PoseExtractionOutput) {
        onPoseFrameReceived(
            poseFrame = output.poseFrame,
            normalizedScreenLandmarks = output.normalizedLandmarks,
            isSimulated = output.isSimulated
        )
    }

    /**
     * Primește un [PoseFrame] de la cameră (la ~30 FPS), extrage [AngleVector] și:
     * 1. Actualizează coordonatele live ale stickman-ului și culoarea sa (verde dacă eroarea < 25°, roșu altfel).
     * 2. Dacă sesiunea este în faza [DrillPhase.RECORDING], adaugă vectorul în bufferul de 600 de cadre.
     * 3. Dacă s-au acumulat toate cele 600 de cadre, declanșează automat evaluarea DTW.
     */
    fun onPoseFrameReceived(
        poseFrame: PoseFrame,
        normalizedScreenLandmarks: List<Point3D> = poseFrame.landmarks,
        isSimulated: Boolean = false
    ) {
        if (poseFrame.landmarks.size < PoseFrame.REQUIRED_LANDMARKS_COUNT) return

        val extractedAngles = JointAngleCalculator.extractAngleVector(poseFrame)
        onAngleVectorCaptured(
            angleVector = extractedAngles,
            normalizedScreenLandmarks = normalizedScreenLandmarks,
            isSimulated = isSimulated
        )
    }

    /**
     * Procesează un [AngleVector] extras și îl adaugă în bufferul de 600 de cadre dacă drill-ul este activ.
     */
    fun onAngleVectorCaptured(
        angleVector: AngleVector,
        normalizedScreenLandmarks: List<Point3D> = _uiState.value.liveNormalizedLandmarks,
        isSimulated: Boolean = _uiState.value.isSimulationMode
    ) {
        val currentState = _uiState.value
        val referenceFrames = currentState.selectedDance?.frames.orEmpty()

        var bufferSizeAfterAdd = currentState.capturedFramesCount
        var reachedFullCapacity = false

        if (currentState.phase == DrillPhase.RECORDING) {
            synchronized(bufferLock) {
                if (angleBuffer.size < MAX_BUFFER_FRAMES) {
                    angleBuffer.add(angleVector)
                    bufferSizeAfterAdd = angleBuffer.size
                    if (angleBuffer.size >= MAX_BUFFER_FRAMES) {
                        reachedFullCapacity = true
                    }
                }
            }
        }

        // Calculăm eroarea instantanee față de cadrul corespunzător din referință
        // pentru a decide dacă stickman-ul de pe ecran este desenat VERDE (corect) sau ROȘU (greșit)
        val referenceIndex = if (referenceFrames.isNotEmpty()) {
            (bufferSizeAfterAdd - 1).coerceIn(0, referenceFrames.lastIndex)
        } else {
            -1
        }

        val instantError = if (referenceIndex >= 0) {
            DtwEngine.frameDistance(angleVector, referenceFrames[referenceIndex])
        } else {
            0f
        }

        val isAccurateNow = instantError <= LIVE_FORM_ERROR_THRESHOLD_DEG

        _uiState.update { state ->
            state.copy(
                capturedFramesCount = bufferSizeAfterAdd,
                liveNormalizedLandmarks = normalizedScreenLandmarks,
                liveAngleVector = angleVector,
                isLiveFormAccurate = isAccurateNow,
                currentInstantErrorDeg = instantError,
                isSimulationMode = isSimulated
            )
        }

        if (reachedFullCapacity) {
            timerJob?.cancel()
            finishAndEvaluateDrill()
        }
    }

    /**
     * Oprește înregistrarea și lansează calculul DTW în `viewModelScope` pe `defaultDispatcher`
     * pentru a nu bloca firul principal (UI).
     */
    fun finishAndEvaluateDrill() {
        val currentState = _uiState.value
        if (currentState.phase == DrillPhase.EVALUATING || currentState.phase == DrillPhase.COMPLETED) {
            return
        }

        timerJob?.cancel()

        val capturedSnapshot: List<AngleVector> = synchronized(bufferLock) {
            angleBuffer.toList()
        }

        val referenceFrames: List<AngleVector> = currentState.selectedDance?.frames
            ?: DefaultDanceRepository.builtInReferenceDances().first().frames

        _uiState.update {
            it.copy(
                phase = DrillPhase.EVALUATING,
                remainingSeconds = 0,
                capturedFramesCount = capturedSnapshot.size
            )
        }

        evaluationJob = viewModelScope.launch {
            val result: DrillResult = withContext(defaultDispatcher) {
                // Dacă utilizatorul a oprit testul fără niciun cadru de la cameră (ex: pe un emulator fără cameră),
                // folosim o secvență demonstrativă din referință ca fallback sigur pentru a nu returna 0%.
                val effectiveUserFrames = if (capturedSnapshot.isNotEmpty()) {
                    capturedSnapshot
                } else {
                    referenceFrames
                }

                DtwEngine.evaluateDrill(
                    userFrames = effectiveUserFrames,
                    referenceFrames = referenceFrames,
                    windowSize = DtwEngine.DEFAULT_SAKOE_CHIBA_BAND
                )
            }

            _uiState.update {
                it.copy(
                    phase = DrillPhase.COMPLETED,
                    lastDrillResult = result
                )
            }
            _events.tryEmit(DrillEvent.NavigateToResults(result))
        }
    }

    /**
     * Resetează starea sesiunii pentru un nou antrenament (Drill).
     */
    fun resetDrill() {
        timerJob?.cancel()
        evaluationJob?.cancel()
        synchronized(bufferLock) {
            angleBuffer.clear()
        }
        val durationSec = _uiState.value.selectedDance?.durationSec ?: EngineConfig.DRILL_DURATION_SECONDS
        _uiState.update {
            it.copy(
                phase = DrillPhase.READY,
                remainingSeconds = durationSec,
                capturedFramesCount = 0,
                currentInstantErrorDeg = 0f,
                isLiveFormAccurate = true,
                errorMessage = null
            )
        }
    }

    /**
     * Returnează o copie nemodificabilă a bufferului curent de [AngleVector] (util pentru testare și debugging).
     */
    fun getCapturedBufferSnapshot(): List<AngleVector> = synchronized(bufferLock) {
        angleBuffer.toList()
    }

    companion object {
        const val MAX_BUFFER_FRAMES = EngineConfig.EXPECTED_FRAMES // 600 cadre (20s * 30 FPS)
        const val PRE_COUNTDOWN_SECONDS = 3
        const val TARGET_TILT_DEG = 90.0f
        const val CALIBRATION_TOLERANCE_DEG = 8.0f
        const val LIVE_FORM_ERROR_THRESHOLD_DEG = 22.0f

        /**
         * Factory pentru instanțierea [DrillViewModel] în Jetpack Compose (`viewModel(factory = ...)`).
         */
        fun provideFactory(
            repository: DanceRepository = DefaultDanceRepository()
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return DrillViewModel(repository = repository) as T
            }
        }
    }
}
