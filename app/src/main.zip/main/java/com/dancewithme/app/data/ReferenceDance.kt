package com.dancewithme.app.data

import kotlinx.serialization.Serializable

/**
 * Modelul unui dans de referință (deserializat din JSON).
 *
 * @property id Identificatorul unic al dansului.
 * @property title Titlul afișat în meniul principal.
 * @property durationSec Durata exercițiului în secunde (standard: 20 secunde).
 * @property frames Lista secvențială de [AngleVector] (ex: 600 cadre pentru 20s @ 30 FPS).
 */
@Serializable
data class ReferenceDance(
    val id: String,
    val title: String,
    val durationSec: Int = 20,
    val frames: List<AngleVector>
)
