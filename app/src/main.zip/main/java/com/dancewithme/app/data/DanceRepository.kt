package com.dancewithme.app.data

import android.content.Context
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlin.math.cos
import kotlin.math.sin

/**
 * Interfața Repository-ului pentru obținerea dansurilor de referință (Clean Architecture).
 */
interface DanceRepository {
    suspend fun getAvailableDances(): List<ReferenceDance>
    suspend fun getDanceById(danceId: String): ReferenceDance?
    fun parseReferenceDanceJson(jsonString: String): ReferenceDance
    fun serializeReferenceDance(dance: ReferenceDance): String
}

/**
 * Implementarea [DanceRepository] care suportă parsarea din JSON (Assets / Rețea)
 * și include coregrafii de referință pre-calibrate la 30 FPS (600 cadre / 20 secunde).
 */
class DefaultDanceRepository(
    private val context: Context? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : DanceRepository {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        prettyPrint = false
    }

    override suspend fun getAvailableDances(): List<ReferenceDance> = withContext(ioDispatcher) {
        val assetDances = loadDancesFromAssetsIfAvailable()
        if (assetDances.isNotEmpty()) {
            assetDances
        } else {
            builtInReferenceDances()
        }
    }

    override suspend fun getDanceById(danceId: String): ReferenceDance? = withContext(ioDispatcher) {
        getAvailableDances().find { it.id == danceId }
    }

    override fun parseReferenceDanceJson(jsonString: String): ReferenceDance {
        return json.decodeFromString(ReferenceDance.serializer(), jsonString)
    }

    override fun serializeReferenceDance(dance: ReferenceDance): String {
        return json.encodeToString(ReferenceDance.serializer(), dance)
    }

    private fun loadDancesFromAssetsIfAvailable(): List<ReferenceDance> {
        val ctx = context ?: return emptyList()
        return try {
            val files = ctx.assets.list("dances")?.filter { it.endsWith(".json") }.orEmpty()
            files.mapNotNull { fileName ->
                runCatching {
                    val rawJson = ctx.assets.open("dances/$fileName").bufferedReader().use { it.readText() }
                    parseReferenceDanceJson(rawJson)
                }.getOrNull()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val DEFAULT_DURATION_SEC = 20
        private const val DEFAULT_FPS = 30
        private const val TOTAL_FRAMES = DEFAULT_DURATION_SEC * DEFAULT_FPS // 600 cadre

        /**
         * Generează dansuri de referință realiste (600 cadre @ 30 FPS) cu traiectorii
         * sinusoidale continue ale unghiurilor articulare, ideale pentru antrenament și testarea DTW.
         */
        fun builtInReferenceDances(): List<ReferenceDance> = listOf(
            createBasicGrooveDance(),
            createSalsaBasicStepDance(),
            createHipHopWaveDance()
        )

        private fun createBasicGrooveDance(): ReferenceDance {
            val frames = List(TOTAL_FRAMES) { frameIdx ->
                val t = frameIdx.toFloat() / DEFAULT_FPS // timpul în secunde [0..20]
                val phase = (t * Math.PI * 2.0).toFloat() // 1 ciclu pe secundă (60 BPM groove)

                AngleVector(
                    genunchiStang = 155f + 20f * sin(phase),
                    genunchiDrept = 155f + 20f * sin(phase),
                    soldStang = 160f + 15f * cos(phase),
                    soldDrept = 160f - 15f * cos(phase),
                    cotStang = 110f + 35f * sin(phase),
                    cotDrept = 110f + 35f * cos(phase)
                )
            }
            return ReferenceDance(
                id = "basic_groove_01",
                title = "Basic Groove & Bounce",
                durationSec = DEFAULT_DURATION_SEC,
                frames = frames
            )
        }

        private fun createSalsaBasicStepDance(): ReferenceDance {
            val frames = List(TOTAL_FRAMES) { frameIdx ->
                val t = frameIdx.toFloat() / DEFAULT_FPS
                val phase = (t * Math.PI * 3.0).toFloat() // 1.5 cicluri pe secundă (90 BPM Salsa)

                AngleVector(
                    genunchiStang = 150f + 25f * sin(phase),
                    genunchiDrept = 150f - 25f * sin(phase),
                    soldStang = 155f + 20f * sin(phase),
                    soldDrept = 155f - 20f * sin(phase),
                    cotStang = 95f + 15f * cos(phase),
                    cotDrept = 95f - 15f * cos(phase)
                )
            }
            return ReferenceDance(
                id = "salsa_basic_02",
                title = "Salsa Basic Step",
                durationSec = DEFAULT_DURATION_SEC,
                frames = frames
            )
        }

        private fun createHipHopWaveDance(): ReferenceDance {
            val frames = List(TOTAL_FRAMES) { frameIdx ->
                val t = frameIdx.toFloat() / DEFAULT_FPS
                val phase = (t * Math.PI * 2.5).toFloat()

                AngleVector(
                    genunchiStang = 140f + 25f * cos(phase),
                    genunchiDrept = 140f + 25f * cos(phase),
                    soldStang = 145f + 20f * sin(phase),
                    soldDrept = 145f + 20f * sin(phase),
                    cotStang = 90f + 50f * sin(phase),
                    cotDrept = 90f + 50f * sin(phase + 1.5f)
                )
            }
            return ReferenceDance(
                id = "hiphop_wave_03",
                title = "Hip-Hop Arm Wave & Squat",
                durationSec = DEFAULT_DURATION_SEC,
                frames = frames
            )
        }
    }
}
