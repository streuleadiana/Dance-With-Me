package com.dancewithme.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.dancewithme.app.data.DrillResult
import com.dancewithme.app.data.DefaultDanceRepository

/**
 * Graficul de navigare Jetpack Compose (`NavHost`) care conectează:
 * - `MainMenuScreen`
 * - `CalibrationScreen`
 * - `DrillScreen`
 * - `ResultScreen`
 */
@Composable
fun DanceWithMeNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    viewModel: DrillViewModel = viewModel(factory = DrillViewModel.provideFactory()),
    onSpeakResult: (DrillResult) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Ascultăm evenimentele one-shot din ViewModel (ex: navigarea automată la ResultScreen după cele 20s)
    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is DrillEvent.NavigateToResults -> {
                    navController.navigate(AppScreen.Results.route) {
                        launchSingleTop = true
                    }
                }
                is DrillEvent.ShowMessage -> Unit
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = AppScreen.MainMenu.route,
        modifier = modifier
    ) {
        composable(route = AppScreen.MainMenu.route) {
            MainMenuScreen(
                dances = uiState.availableDances,
                onDanceSelected = { dance ->
                    viewModel.selectDance(dance.id)
                    navController.navigate(AppScreen.Calibration.createRoute(dance.id))
                }
            )
        }

        composable(route = AppScreen.Calibration.route) { backStackEntry ->
            val danceId = backStackEntry.arguments?.getString("danceId")
            LaunchedEffect(danceId) {
                if (danceId != null) {
                    viewModel.selectDance(danceId)
                }
            }

            CalibrationScreen(
                danceTitle = uiState.selectedDance?.title ?: "Antrenament Dans",
                currentTiltDeg = uiState.currentPhoneTiltDeg,
                isCalibrated = uiState.isCalibrated,
                onTiltUpdated = viewModel::updatePhoneTilt,
                onProceedToDrill = {
                    val targetId = uiState.selectedDance?.id ?: danceId ?: "basic_groove_01"
                    viewModel.resetDrill()
                    navController.navigate(AppScreen.Drill.createRoute(targetId))
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(route = AppScreen.Drill.route) { backStackEntry ->
            val danceId = backStackEntry.arguments?.getString("danceId")
            LaunchedEffect(danceId) {
                if (danceId != null && uiState.selectedDance?.id != danceId) {
                    viewModel.selectDance(danceId)
                }
            }

            DrillScreen(
                uiState = uiState,
                onPoseOutput = viewModel::onPoseExtractionOutput,
                onStartDrill = { viewModel.startDrill(withPreCountdown = true) },
                onStopAndEvaluate = viewModel::finishAndEvaluateDrill,
                onBack = {
                    viewModel.resetDrill()
                    navController.popBackStack()
                }
            )
        }

        composable(route = AppScreen.Results.route) {
            val result = uiState.lastDrillResult ?: DrillResult(
                totalScore = 0f,
                formScore = 0f,
                timingScore = 0f,
                jointErrors = emptyMap()
            )
            val danceTitle = uiState.selectedDance?.title
                ?: DefaultDanceRepository.builtInReferenceDances().first().title

            ResultScreen(
                danceTitle = danceTitle,
                result = result,
                onSpeakResult = onSpeakResult,
                onRetryDrill = {
                    viewModel.resetDrill()
                    navController.popBackStack()
                },
                onBackToMenu = {
                    viewModel.resetDrill()
                    navController.popBackStack(AppScreen.MainMenu.route, inclusive = false)
                }
            )
        }
    }
}
