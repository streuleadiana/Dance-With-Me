package com.dancewithme.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dancewithme.app.ai.PoseExtractionOutput
import com.dancewithme.app.ai.PoseLandmarkerHelper
import com.dancewithme.app.audio.VoskVoiceCommandManager
import com.dancewithme.app.camera.CameraSessionManager
import com.dancewithme.app.camera.PoseAnalyzer
import com.dancewithme.app.data.Point3D
import com.dancewithme.app.data.PoseFrame
import kotlinx.coroutines.delay

/**
 * Ecranul de antrenament (`DrillScreen`):
 * - Cere permisiunile `CAMERA` și `RECORD_AUDIO` (pentru Vosk).
 * - Pornește `VoskVoiceCommandManager` în faza `READY` pentru a detecta comanda vocală offline `"Start"`.
 * - Randează `CameraPreview` (`PreviewView` din CameraX).
 * - Randează un `Canvas` peste cameră care desenează în timp real scheletul (*stickman*-ul)
 *   colorat în **VERDE** (când unghiurile sunt apropiate de referință) sau **ROȘU** (când postura are erori).
 * - Afișează numărătoarea inversă de 20 de secunde și progresul bufferului de 600 de cadre.
 */
@Composable
fun DrillScreen(
    uiState: DrillUiState,
    onPoseOutput: (PoseExtractionOutput) -> Unit,
    onStartDrill: () -> Unit,
    onStopAndEvaluate: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val voskManager = remember(context) {
        VoskVoiceCommandManager(
            context = context,
            onStartCommandDetected = onStartDrill
        )
    }
    val voiceStatusLabel by voskManager.statusMessage.collectAsStateWithLifecycle()

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasCameraPermission = result[Manifest.permission.CAMERA] ?: hasCameraPermission
        hasAudioPermission = result[Manifest.permission.RECORD_AUDIO] ?: hasAudioPermission
        if (hasAudioPermission && uiState.phase == DrillPhase.READY) {
            voskManager.startListening()
        }
    }

    LaunchedEffect(Unit) {
        val needed = mutableListOf<String>()
        if (!hasCameraPermission) needed.add(Manifest.permission.CAMERA)
        if (!hasAudioPermission) needed.add(Manifest.permission.RECORD_AUDIO)
        if (needed.isNotEmpty()) {
            permissionsLauncher.launch(needed.toTypedArray())
        }
    }

    // Gestionăm ciclul de viață al recunoașterii vocale Vosk:
    // Ascultă în faza READY și se oprește automat când începe dansul sau la părăsirea ecranului.
    DisposableEffect(voskManager, uiState.phase, hasAudioPermission) {
        if (uiState.phase == DrillPhase.READY) {
            voskManager.startListening()
        } else {
            voskManager.stopListening()
        }
        onDispose {
            voskManager.stopListening()
        }
    }

    DisposableEffect(voskManager) {
        onDispose {
            voskManager.shutdown()
        }
    }

    // Fallback generator la 30 FPS: dacă pe emulator camera nu trimite cadre sau nu are permisiune,
    // menținem fluxul de 30 FPS ca să poți vedea stickman-ul animat și să poți testa cele 20 de secunde + DTW.
    var lastCameraFrameTimeMs by remember { mutableStateOf(0L) }
    LaunchedEffect(uiState.phase, hasCameraPermission) {
        while (true) {
            delay(33L) // ~30 FPS
            val now = android.os.SystemClock.uptimeMillis()
            if (!hasCameraPermission || (now - lastCameraFrameTimeMs) > 450L) {
                val simulated = PoseLandmarkerHelper.generateSimulatedPoseOutput(now)
                onPoseOutput(simulated)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Stratul de bază: CameraX PreviewView
        if (hasCameraPermission) {
            val previewView = remember {
                PreviewView(context).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
            }
            val cameraSessionManager = remember { CameraSessionManager(context) }

            DisposableEffect(lifecycleOwner, previewView) {
                val analyzer = PoseAnalyzer.create(
                    context = context,
                    isFrontCamera = true,
                    onPoseFrame = {},
                    onPoseOutput = { output ->
                        lastCameraFrameTimeMs = android.os.SystemClock.uptimeMillis()
                        onPoseOutput(output)
                    }
                )
                cameraSessionManager.startCamera(
                    lifecycleOwner = lifecycleOwner,
                    previewView = previewView,
                    poseAnalyzer = analyzer,
                    useFrontCamera = true
                )
                onDispose {
                    cameraSessionManager.shutdown()
                }
            }

            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize()
            )
        }

        // 2. Stratul de mijloc: Canvas-ul care desenează Stickman-ul 3D (Verde = Corect, Roșu = Eroare)
        StickmanOverlayCanvas(
            landmarks = uiState.liveNormalizedLandmarks,
            isFormAccurate = uiState.isLiveFormAccurate,
            modifier = Modifier.fillMaxSize()
        )

        // 3. Stratul superior (HUD): Numărătoare inversă, Progres 600 cadre și Butoane de control + Vosk
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header HUD
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color.Black.copy(alpha = 0.72f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = uiState.selectedDance?.title ?: "Antrenament Dans",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "🎤 $voiceStatusLabel",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF80CBC4)
                            )
                        }

                        // Badge Timp Rămas (20s -> 0s)
                        Surface(
                            color = if (uiState.phase == DrillPhase.RECORDING) {
                                Color(0xFFD32F2F)
                            } else {
                                Color(0xFF1976D2)
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "${uiState.remainingSeconds}s",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Bara de progres pentru bufferul de 600 de cadre (20s * 30 FPS)
                    val frameProgress = (uiState.capturedFramesCount.toFloat() / uiState.maxFramesCapacity.toFloat())
                        .coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { frameProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = if (uiState.isLiveFormAccurate) Color(0xFF00E676) else Color(0xFFFF5252),
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Cadre: ${uiState.capturedFramesCount} / ${uiState.maxFramesCapacity}",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White
                        )
                        Text(
                            text = if (uiState.isLiveFormAccurate) {
                                "Postură: CORECTĂ (Verde)"
                            } else {
                                "Postură: CORECTEAZĂ UNGHIUL (Roșu)"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.isLiveFormAccurate) Color(0xFF00E676) else Color(0xFFFF5252)
                        )
                    }
                }
            }

            // Indicator central dacă suntem în numărătoarea 3..2..1 sau în calculul DTW
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when (uiState.phase) {
                    DrillPhase.COUNTDOWN_TO_START -> {
                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Text(
                                text = "${uiState.preDrillCountdownSec}",
                                style = MaterialTheme.typography.displayLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF00E676),
                                modifier = Modifier.padding(horizontal = 40.dp, vertical = 20.dp)
                            )
                        }
                    }
                    DrillPhase.EVALUATING -> {
                        Surface(
                            color = Color.Black.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                CircularProgressIndicator(color = Color(0xFF00E676))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Se calculează scorul DTW...",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                    }
                    else -> Unit
                }
            }

            // Footer: Butoane de Start / Comandă Vocală Vosk / Evaluare rapidă / Înapoi
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color.Black.copy(alpha = 0.72f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (uiState.phase == DrillPhase.READY) {
                        OutlinedButton(
                            onClick = { voskManager.triggerSimulatedVoiceStart() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🎤 Simulează Comanda Vocală Vosk: „START”",
                                color = Color(0xFF80CBC4),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onBack,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Înapoi", color = Color.White)
                        }

                        if (uiState.phase == DrillPhase.READY) {
                            Button(
                                onClick = onStartDrill,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF00C853)
                                ),
                                modifier = Modifier.weight(2f)
                            ) {
                                Text(
                                    text = "START DANS (20s)",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else if (uiState.phase == DrillPhase.RECORDING) {
                            Button(
                                onClick = onStopAndEvaluate,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFF6D00)
                                ),
                                modifier = Modifier.weight(2f)
                            ) {
                                Text(
                                    text = "Finalizează & Calculează DTW",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Desenează scheletul (Stickman-ul) peste fluxul video folosind coordonatele normalizate [0..1].
 * Culoarea este verde strălucitor când `isFormAccurate == true` și roșie când `isFormAccurate == false`.
 */
@Composable
fun StickmanOverlayCanvas(
    landmarks: List<Point3D>,
    isFormAccurate: Boolean,
    modifier: Modifier = Modifier
) {
    val boneColor = if (isFormAccurate) Color(0xFF00E676) else Color(0xFFFF1744)
    val jointColor = Color.White

    Canvas(modifier = modifier) {
        if (landmarks.size < PoseFrame.REQUIRED_LANDMARKS_COUNT) return@Canvas

        fun Point3D.toScreenOffset(): Offset = Offset(
            x = x.coerceIn(0f, 1f) * size.width,
            y = y.coerceIn(0f, 1f) * size.height
        )

        // Conexiunile anatomice pentru desenarea stickman-ului
        val connections = listOf(
            // Linia umerilor și trunchiul
            PoseFrame.LEFT_SHOULDER to PoseFrame.RIGHT_SHOULDER,
            PoseFrame.LEFT_SHOULDER to PoseFrame.LEFT_HIP,
            PoseFrame.RIGHT_SHOULDER to PoseFrame.RIGHT_HIP,
            PoseFrame.LEFT_HIP to PoseFrame.RIGHT_HIP,
            // Brațul stâng
            PoseFrame.LEFT_SHOULDER to PoseFrame.LEFT_ELBOW,
            PoseFrame.LEFT_ELBOW to PoseFrame.LEFT_WRIST,
            // Brațul drept
            PoseFrame.RIGHT_SHOULDER to PoseFrame.RIGHT_ELBOW,
            PoseFrame.RIGHT_ELBOW to PoseFrame.RIGHT_WRIST,
            // Piciorul stâng
            PoseFrame.LEFT_HIP to PoseFrame.LEFT_KNEE,
            PoseFrame.LEFT_KNEE to PoseFrame.LEFT_ANKLE,
            // Piciorul drept
            PoseFrame.RIGHT_HIP to PoseFrame.RIGHT_KNEE,
            PoseFrame.RIGHT_KNEE to PoseFrame.RIGHT_ANKLE
        )

        // Desenăm gâtul și capul (de la mijlocul umerilor la nas)
        val leftShoulder = landmarks[PoseFrame.LEFT_SHOULDER].toScreenOffset()
        val rightShoulder = landmarks[PoseFrame.RIGHT_SHOULDER].toScreenOffset()
        val shoulderMid = Offset(
            x = (leftShoulder.x + rightShoulder.x) * 0.5f,
            y = (leftShoulder.y + rightShoulder.y) * 0.5f
        )
        val headCenter = landmarks[PoseFrame.NOSE].toScreenOffset()

        drawLine(
            color = boneColor,
            start = shoulderMid,
            end = headCenter,
            strokeWidth = 6.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawCircle(
            color = boneColor,
            radius = 22.dp.toPx(),
            center = headCenter
        )

        // Desenăm segmentele osoase
        for ((startIdx, endIdx) in connections) {
            val startPt = landmarks[startIdx]
            val endPt = landmarks[endIdx]
            drawLine(
                color = boneColor,
                start = startPt.toScreenOffset(),
                end = endPt.toScreenOffset(),
                strokeWidth = 7.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Desenăm articulațiile principale
        val keyJointIndices = listOf(
            PoseFrame.LEFT_SHOULDER,
            PoseFrame.RIGHT_SHOULDER,
            PoseFrame.LEFT_ELBOW,
            PoseFrame.RIGHT_ELBOW,
            PoseFrame.LEFT_WRIST,
            PoseFrame.RIGHT_WRIST,
            PoseFrame.LEFT_HIP,
            PoseFrame.RIGHT_HIP,
            PoseFrame.LEFT_KNEE,
            PoseFrame.RIGHT_KNEE,
            PoseFrame.LEFT_ANKLE,
            PoseFrame.RIGHT_ANKLE
        )

        for (idx in keyJointIndices) {
            val offset = landmarks[idx].toScreenOffset()
            drawCircle(
                color = boneColor,
                radius = 9.dp.toPx(),
                center = offset
            )
            drawCircle(
                color = jointColor,
                radius = 5.dp.toPx(),
                center = offset
            )
        }
    }
}
